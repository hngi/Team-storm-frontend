# square-hotel
Frontend code for square hotel
